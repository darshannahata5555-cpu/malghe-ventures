(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const clone = value => JSON.parse(JSON.stringify(value));
  const icons = {
    home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 6-6 4 4 3-3 5 5"/>',
    projects:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V3h8v4M8 12v4m4-4v4m4-4v4"/>',
    media:'<rect x="7" y="3" width="14" height="14" rx="2"/><path d="M3 7v12a2 2 0 0 0 2 2h12m-7-12 3-3 4 4"/>',
    arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',
    external:'<path d="M14 3h7v7m0-7L10 14M10 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5"/>',
    logout:'<path d="M9 4H4v16h5m5-12 4 4-4 4m-5-4h12"/>',
    search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
    plus:'<path d="M12 4v16M4 12h16"/>',
    upload:'<path d="M12 16V3m-5 5 5-5 5 5M4 15v5h16v-5"/>',
    check:'<path d="m4 12 5 5L20 6"/>',
    star:'<path d="m12 3 2.8 5.7L21 9.6l-4.5 4.5 1 6.2-5.5-3-5.5 3 1-6.2L3 9.6l6.2-.9z"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>'
  };
  const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.image}</svg>`;
  const S = {section:'overview', session:null, csrf:'', draft:null, catalogue:[], media:[], dirty:false, publishedRevision:0, publishedAt:null, page:'All pages', query:'', projectFilter:'all', projectQuery:'', busy:false};
  let setupKey = new URLSearchParams(location.hash.slice(1)).get('setup') || '';
  if (setupKey) history.replaceState(null, '', location.pathname + '#overview');
  const editor = $('#editor'), picker = $('#media-picker');
  let editingImage = null, editingProject = null, mediaCallback = null, mediaMultiple = false, picked = new Set(), pickerTab = 'uploads', toastTimer;

  async function api(action, body, extraHeaders = {}) {
    const options = {credentials:'same-origin', cache:'no-store', headers:{...extraHeaders}};
    if (body !== undefined) {
      options.method = 'POST'; options.headers['X-CSRF-Token'] = S.csrf;
      if (body instanceof FormData) options.body = body;
      else { options.headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(body); }
    }
    const response = await fetch('/cms/api.php?action=' + action, options);
    let data;
    try { data = await response.json(); } catch { throw new Error('The server did not respond. Please try again.'); }
    if (!response.ok) {
      const error = new Error(data.error || 'This change could not be saved.'); error.status = response.status;
      if (S.session?.authenticated && action !== 'login' && (response.status === 401 || (response.status === 403 && error.message.includes('Your session expired')))) reauthenticate();
      throw error;
    }
    return data;
  }

  function toast(message, error = false, undo = null) {
    const node = $('#toast'); clearTimeout(toastTimer);
    node.className = 'toast is-visible' + (error ? ' is-error' : ''); node.textContent = message;
    if (undo) { const button = document.createElement('button'); button.textContent = 'Undo'; button.onclick = () => { undo(); node.classList.remove('is-visible'); }; node.append(button); }
    toastTimer = setTimeout(() => node.classList.remove('is-visible'), undo ? 10000 : 5000);
  }
  const date = value => value ? new Intl.DateTimeFormat(undefined, {day:'numeric',month:'short',year:'numeric',hour:'numeric',minute:'2-digit'}).format(new Date(value)) : 'Not published yet';
  const effective = item => S.draft.images[item.id] || {src:item.src,alt:item.alt,focusX:50,focusY:50};
  const imageSrc = src => S.draft.images[src]?.src || src;
  const usedImages = () => S.catalogue.filter(item => item.uses.length);
  const liveProjects = () => S.draft.projects.filter(project => !project.archived);
  function markDirty() { S.dirty = true; updateHeader(); }

  function authScreen(error = '') {
    const needsSetup = S.session?.needsSetup;
    const canSetup = needsSetup && setupKey && S.session.setupAvailable;
    $('#app').innerHTML = `<main class="auth-layout"><section class="auth-story"><img class="auth-brand" src="/img/logo-light.png" alt="Malghe Ventures"><div><h1>A home for your<br>next chapter.</h1><p>Keep your website as considered as the spaces you create. Update your photos, share your projects, and make it yours.</p></div><small>From land to legacy, we build it all.</small></section><section class="auth-form-side"><div class="auth-form"><div class="eyebrow">Owner workspace</div><h2>${canSetup ? 'Make yourself at home.' : needsSetup ? 'Your workspace is ready.' : 'Welcome back.'}</h2><p>${canSetup ? 'Create the owner login. You’ll use it to manage your website.' : needsSetup ? 'Use your private setup link to create the owner account.' : 'Sign in to manage your images and projects.'}</p><div class="error-message" id="auth-error" role="alert">${esc(error)}</div>${needsSetup && !canSetup ? '<div class="auth-note">Owner setup is protected. Open the private setup link supplied with your website to choose your username and password.</div>' : `<form id="auth-form"><label>Username<input name="username" autocomplete="username" required minlength="3" maxlength="80" ${canSetup ? 'value="owner"' : ''}></label><label>Password<input type="password" name="password" autocomplete="${canSetup ? 'new-password' : 'current-password'}" required ${canSetup ? 'minlength="12" maxlength="72"' : ''}></label>${canSetup ? '<label>Confirm password<input type="password" name="confirmPassword" autocomplete="new-password" required minlength="12" maxlength="72"></label><p class="field-help">Choose a unique password of at least 12 characters.</p>' : ''}<button class="button button--primary" type="submit">${canSetup ? 'Create owner account' : 'Sign in'} ${icon('arrow')}</button></form>`}<a class="auth-back" href="/">${icon('external')} Back to the website</a><p class="auth-footnote">Your changes stay in a draft until you publish them.</p></div></section></main>`;
    $('#auth-form')?.addEventListener('submit', async event => {
      event.preventDefault(); const form = event.currentTarget, fields = new FormData(form), button = $('button[type=submit]', form);
      $('#auth-error').textContent = '';
      if (canSetup && fields.get('password') !== fields.get('confirmPassword')) { $('#auth-error').textContent = 'The passwords do not match.'; return; }
      button.disabled = true;
      try {
        const result = await api(canSetup ? 'setup' : 'login', {username:fields.get('username'),password:fields.get('password')}, canSetup ? {'X-Setup-Key':setupKey} : {});
        S.csrf = result.csrf; S.session = {authenticated:true,username:result.username}; setupKey = '';
        await loadWorkspace();
      } catch (error) { $('#auth-error').textContent = error.message; button.disabled = false; }
    });
  }

  async function loadWorkspace() {
    const [result, media] = await Promise.all([api('draft'), api('media')]);
    S.draft = result.draft; S.draft.images = {...S.draft.images}; S.catalogue = result.catalogue.images; S.media = media.items;
    S.publishedRevision = result.publishedRevision; S.publishedAt = result.publishedAt; S.dirty = false;
    const requested = location.hash.slice(1); if (['overview','images','projects','media'].includes(requested)) S.section = requested;
    shell();
  }

  function shell() {
    $('#app').innerHTML = `<div class="workspace"><aside class="sidebar"><div class="sidebar-brand"><img src="/img/logo-light.png" alt="Malghe Ventures"><span>Owner workspace</span></div><nav aria-label="Workspace"><button class="nav-item" data-nav="overview">${icon('home')} Overview</button><button class="nav-item" data-nav="images">${icon('image')} Website images</button><button class="nav-item" data-nav="projects">${icon('projects')} Projects</button><button class="nav-item" data-nav="media">${icon('media')} Media library</button></nav><div class="sidebar-bottom"><a href="/" target="_blank" rel="noopener">${icon('external')} View website</a><button data-action="logout">${icon('logout')} Sign out</button><div class="owner-badge"><span class="owner-avatar">${esc(S.session.username.slice(0,1).toUpperCase())}</span><span>${esc(S.session.username)}<br>Website owner</span></div></div></aside><header class="topbar"><div class="workspace-label">Malghe Ventures <span>/</span> <b id="current-section">Overview</b></div><div class="topbar-actions"><span class="draft-status" id="draft-status"></span><a class="button button--quiet preview-link" href="/?cms_preview=1" target="_blank" rel="noopener" title="Preview the last saved draft">Preview draft ${icon('external')}</a><button class="button" data-action="save">Save draft</button><button class="button button--primary" data-action="publish">Publish changes ${icon('arrow')}</button></div></header><main class="content" id="content"></main></div>`;
    renderMain(); updateHeader();
  }

  function updateHeader() {
    const node = $('#draft-status'); if (!node) return;
    const unpublished = S.dirty || S.draft.revision !== S.publishedRevision;
    node.innerHTML = `<span class="status-dot ${unpublished ? 'is-draft' : ''}"></span>${S.dirty ? 'Unsaved changes' : unpublished ? 'Draft saved' : 'All changes published'}`;
    for (const button of document.querySelectorAll('[data-action="save"],[data-action="publish"]')) button.disabled = S.busy;
  }

  function renderMain() {
    for (const item of document.querySelectorAll('[data-nav]')) item.classList.toggle('is-active', item.dataset.nav === S.section);
    $('#current-section').textContent = {overview:'Overview',images:'Website images',projects:'Projects',media:'Media library'}[S.section];
    $('.preview-link').href = (S.section === 'projects' ? '/projects/' : '/') + '?cms_preview=1';
    ({overview:renderOverview,images:renderImages,projects:renderProjects,media:renderMedia}[S.section])();
  }

  async function reauthenticate() {
    if (document.getElementById('reauth-dialog')) return;
    const dialog = document.createElement('dialog'); dialog.id = 'reauth-dialog'; dialog.className = 'reauth-dialog';
    dialog.innerHTML = `<div class="dialog-header"><div><h2 id="reauth-title">Sign in again</h2><p>Your unsaved changes are still here.</p></div></div><form id="reauth-form"><div class="dialog-body field-stack"><div class="error-message" id="reauth-error" role="alert"></div><label>Username<input name="username" autocomplete="username" value="${esc(S.session.username)}" required></label><label>Owner password<input type="password" name="password" autocomplete="current-password" required></label></div><div class="dialog-footer"><button class="button button--primary" type="submit">Sign in again</button></div></form>`;
    dialog.setAttribute('aria-labelledby','reauth-title'); document.body.append(dialog); dialog.showModal();
    dialog.addEventListener('cancel',event=>event.preventDefault());
    try { const session = await api('session'); S.csrf = session.csrf; }
    catch (error) { $('#reauth-error').textContent = error.message; }
    $('#reauth-form').onsubmit = async event => {
      event.preventDefault(); const values = new FormData(event.currentTarget), button = $('button',event.currentTarget); button.disabled = true;
      try {
        const result = await api('login',{username:values.get('username'),password:values.get('password')});
        S.csrf = result.csrf; S.session = {authenticated:true,username:result.username}; dialog.close(); dialog.remove(); toast('Signed in. You can save your changes now.');
      } catch (error) { $('#reauth-error').textContent = error.message; button.disabled = false; }
    };
  }

  function heading(eyebrow, title, description, action = '') {
    return `<div class="page-heading"><div><div class="eyebrow">${eyebrow}</div><h1>${title}</h1><p>${description}</p></div>${action}</div>`;
  }

  function renderOverview() {
    const projects = liveProjects();
    const changed = Object.keys(S.draft.images).length;
    $('#content').innerHTML = heading('Your website, in your hands', 'Welcome to your workspace.', 'A simple place to keep your photos fresh and your projects up to date.') + `<section class="overview-welcome"><div><div class="eyebrow">From land to legacy</div><h2>Your next project starts<br>with a good first impression.</h2><p>Replace a website image, add a new development, or share a completed project. Save your work as a draft, then publish when it’s ready.</p></div><div class="publish-summary"><span class="status-dot"></span><h3>${S.draft.revision === S.publishedRevision && !S.dirty ? 'Your website is up to date.' : 'Your draft has unpublished changes.'}</h3><p>Last published<br>${esc(date(S.publishedAt))}</p></div></section><section class="stats-grid"><div class="stat-card"><div class="stat-label">Website images ${icon('image')}</div><strong>${usedImages().length}</strong><small>${changed} ${changed === 1 ? 'photo' : 'photos'} replaced</small></div><div class="stat-card"><div class="stat-label">Completed projects ${icon('projects')}</div><strong>${projects.filter(p => p.status === 'completed').length}</strong><small>Spaces brought to life</small></div><div class="stat-card"><div class="stat-label">Coming soon ${icon('star')}</div><strong>${projects.filter(p => p.status === 'coming_soon').length}</strong><small>What’s on the horizon</small></div></section><h2 class="section-label">What would you like to update?</h2><section class="quick-grid"><button class="quick-card" data-nav="images"><span class="quick-icon">${icon('image')}</span><div><h3>Refresh your website images</h3><p>Choose a photo, upload its replacement, and adjust how it appears.</p></div></button><button class="quick-card" data-nav="projects"><span class="quick-icon">${icon('projects')}</span><div><h3>Share your latest projects</h3><p>Add a coming soon project, mark a project completed, or update its gallery.</p></div></button></section><p class="field-help" style="margin-top:30px">Signed in as ${esc(S.session.username)}. <button class="settings-button" data-action="password">Change password</button></p>`;
  }

  function renderImages() {
    $('#content').innerHTML = heading('A picture of your work', 'Website images', 'Replace photos across your website. Shared images update everywhere they appear.') + `<div class="toolbar"><div class="toolbar-controls"><div class="search-field">${icon('search')}<input id="image-search" aria-label="Search website images" placeholder="Search images…" value="${esc(S.query)}"></div><select id="image-page" aria-label="Filter images by page">${['All pages','Home','About','Services','Projects','Contact'].map(page => `<option ${page === S.page ? 'selected' : ''}>${page}</option>`).join('')}</select></div><span class="result-count" id="image-count"></span></div><div class="image-grid" id="image-grid"></div>`;
    $('#image-search').oninput = event => { S.query = event.target.value; renderImageGrid(); };
    $('#image-page').onchange = event => { S.page = event.target.value; renderImageGrid(); };
    renderImageGrid();
  }

  function renderImageGrid() {
    const images = usedImages().filter(item => (S.page === 'All pages' || item.uses.some(use => use.page === S.page)) && (item.label + ' ' + item.uses.map(use => use.group).join(' ')).toLowerCase().includes(S.query.toLowerCase()));
    $('#image-count').textContent = `${images.length} ${images.length === 1 ? 'image' : 'images'}`;
    $('#image-grid').innerHTML = images.length ? images.map(item => {
      const current = effective(item), uses = [...new Set(item.uses.map(use => use.page))].join(', '), custom = !!S.draft.images[item.id];
      return `<article class="image-card"><button type="button" class="image-card-open ${/logo|monogram/.test(item.id) ? 'logo-image' : ''}" data-edit-image="${esc(item.id)}" aria-label="Replace ${esc(item.label)}"><img src="${esc(current.src)}" alt="${esc(current.alt || item.label)}" loading="lazy" style="object-position:${current.focusX}% ${current.focusY}%">${custom ? '<span class="custom-badge">Updated photo</span>' : ''}</button><div class="image-card-body"><h3>${esc(item.label)}</h3><p class="image-uses">${esc(uses)}</p><div class="image-card-actions"><button class="button button--small" data-edit-image="${esc(item.id)}">Change image</button>${custom ? `<button class="button button--quiet button--small" data-reset-image="${esc(item.id)}">Reset</button>` : ''}</div></div></article>`;
    }).join('') : empty('image','No images found','Try another search or page filter.');
  }

  function renderProjects() {
    $('#content').innerHTML = heading('Made by Malghe Ventures', 'Your projects', 'Share a new development, update its photos, or celebrate a completed project.', `<button class="button button--primary" data-action="add-project">${icon('plus')} Add project</button>`) + `<div class="toolbar"><div class="tabs" role="group" aria-label="Project status">${[['all','All projects'],['coming_soon','Coming soon'],['completed','Completed'],['archived','Archived']].map(([id,label]) => `<button class="tab ${S.projectFilter === id ? 'is-active' : ''}" data-project-filter="${id}">${label}</button>`).join('')}</div><div class="search-field">${icon('search')}<input id="project-search" aria-label="Search projects" placeholder="Search projects…" value="${esc(S.projectQuery)}"></div></div><div class="project-grid" id="project-grid"></div>`;
    $('#project-search').oninput = event => { S.projectQuery = event.target.value; renderProjectGrid(); };
    renderProjectGrid();
  }

  function renderProjectGrid() {
    const projects = S.draft.projects.filter(project => S.projectFilter === 'archived' ? project.archived : !project.archived && (S.projectFilter === 'all' || project.status === S.projectFilter)).filter(project => (project.title + ' ' + project.location).toLowerCase().includes(S.projectQuery.toLowerCase()));
    $('#project-grid').innerHTML = projects.length ? projects.map(project => `<article class="project-card"><div class="project-card-image"><img src="${esc(imageSrc(project.cover))}" alt="${esc(project.title)}" loading="lazy"><span class="project-status ${project.status === 'coming_soon' ? 'coming-soon' : ''}">${project.archived ? 'Archived' : project.status === 'completed' ? 'Completed' : 'Coming soon'}</span></div><div class="project-card-body"><div class="project-meta">${esc(project.category)}${!project.visible ? ' · Hidden from website' : ''}</div><h3>${esc(project.title)}</h3><p class="project-location">${esc(project.location)}</p><div class="project-card-bottom">${project.featured ? `<span class="featured-note">${icon('star')} Featured on home</span>` : '<span></span>'}${project.archived ? `<button class="button button--small" data-restore-project="${esc(project.id)}">Restore</button>` : `<button class="button button--small" data-edit-project="${esc(project.id)}">Edit project ${icon('arrow')}</button>`}</div></div></article>`).join('') : empty('projects','No projects here yet',S.projectFilter === 'archived' ? 'Archived projects can be restored here.' : 'Add a project to share it on your website.');
  }

  function renderMedia() {
    $('#content').innerHTML = heading('Your photo collection', 'Media library', 'Upload photos once, then use them in your website images and project galleries.', `<label class="button button--primary upload-button">${icon('upload')} Upload images<input type="file" accept="image/jpeg,image/png,image/webp,image/avif" multiple data-upload="library"></label>`) + `<div class="toolbar"><p class="result-count">${S.media.length} uploaded ${S.media.length === 1 ? 'image' : 'images'}</p><p class="field-help">JPG, PNG, WebP or AVIF · Up to 10 MB each</p></div><div class="image-grid media-library-grid">${S.media.length ? S.media.map(item => `<article class="image-card"><div class="image-card-open"><img src="${esc(item.src)}" alt="${esc(item.name)}" loading="lazy"></div><div class="image-card-body"><h3 class="media-name" title="${esc(item.name)}">${esc(item.name)}</h3><p class="media-meta">${item.width} × ${item.height} · ${(item.bytes / 1048576).toFixed(1)} MB</p></div></article>`).join('') : empty('media','Your photo collection starts here','Upload a few photos, then choose them when editing an image or project.')}</div>`;
  }

  function empty(name, title, description) { return `<div class="empty-state">${icon(name)}<h3>${title}</h3><p>${description}</p></div>`; }

  function openEditor(title, subtitle, body, footer, formId = '') {
    editor.innerHTML = `<div class="dialog-header"><div><h2 id="editor-title">${esc(title)}</h2>${subtitle ? `<p>${esc(subtitle)}</p>` : ''}</div><button class="icon-button" data-close-editor aria-label="Close editor">${icon('close')}</button></div>${formId ? `<form id="${formId}">` : ''}<div class="dialog-body"><div class="error-message" id="editor-error" role="alert"></div>${body}</div><div class="dialog-footer">${footer}</div>${formId ? '</form>' : ''}`;
    if (!editor.open) editor.showModal();
  }

  function editImage(id) {
    const item = S.catalogue.find(entry => entry.id === id); if (!item) return;
    editingImage = {id,...clone(effective(item))};
    openEditor('Change image', item.label, `<div class="image-editor-grid"><div><div class="editor-image-preview"><img id="image-preview" src="${esc(editingImage.src)}" alt="${esc(editingImage.alt)}" style="object-position:${editingImage.focusX}% ${editingImage.focusY}%"></div><div class="editor-upload-actions"><label class="button button--small upload-button">${icon('upload')} Upload image<input type="file" accept="image/jpeg,image/png,image/webp,image/avif" data-upload="image"></label><button class="button button--small" type="button" data-pick-image>Choose from library</button></div><p class="field-help" style="margin-top:12px">JPG, PNG, WebP or AVIF, up to 10 MB.</p></div><div class="field-stack"><label>Image description<input name="alt" aria-label="Image description" maxlength="500" value="${esc(editingImage.alt)}"><span class="field-help">Describe the image for people using screen readers. Leave decorative backgrounds blank.</span></label><label><span class="range-label">Horizontal focus <output id="focus-x-value">${editingImage.focusX}%</output></span><input type="range" name="focusX" min="0" max="100" value="${editingImage.focusX}"></label><label><span class="range-label">Vertical focus <output id="focus-y-value">${editingImage.focusY}%</output></span><input type="range" name="focusY" min="0" max="100" value="${editingImage.focusY}"><span class="field-help">Move the focus to keep the important part visible when the image is cropped.</span></label></div></div>`, '<p class="field-help">This image updates everywhere it is used.</p><div class="dialog-footer-actions"><button class="button" type="button" data-close-editor>Cancel</button><button class="button button--primary" type="submit">Use this image</button></div>', 'image-form');
    $('#image-form').oninput = event => {
      if (event.target.type !== 'range') return;
      editingImage[event.target.name] = Number(event.target.value);
      $('#focus-x-value').textContent = editingImage.focusX + '%'; $('#focus-y-value').textContent = editingImage.focusY + '%';
      $('#image-preview').style.objectPosition = `${editingImage.focusX}% ${editingImage.focusY}%`;
    };
    $('#image-form').onsubmit = event => {
      event.preventDefault(); editingImage.alt = new FormData(event.currentTarget).get('alt');
      const {src,alt,focusX,focusY} = editingImage; S.draft.images[id] = {src,alt,focusX,focusY}; markDirty(); editor.close(); renderMain(); toast('Image updated in your draft.');
    };
  }

  function editProject(id) {
    const found = S.draft.projects.find(project => project.id === id);
    editingProject = found ? clone(found) : {id:'project-' + crypto.randomUUID(),title:'',location:'',category:'Premium plotting',status:'coming_soon',summary:'',description:'',cover:'',gallery:[],features:[],visible:true,archived:false,featured:false};
    const p = editingProject;
    openEditor(found ? 'Edit project' : 'Add a project', 'Tell the story of your next development.', `<div class="field-grid"><label>Project name<input name="title" aria-label="Project name" value="${esc(p.title)}" maxlength="160" required placeholder="For example, Dream City Phase II"></label><label>Location<input name="location" aria-label="Location" value="${esc(p.location)}" maxlength="160" required placeholder="Chakan, Pune"></label><label>Project type<select name="category" aria-label="Project type">${['Premium plotting','Construction','Interiors','Real estate'].map(value => `<option ${p.category === value ? 'selected' : ''}>${value}</option>`).join('')}</select></label><label>Status<select name="status" aria-label="Status"><option value="coming_soon" ${p.status === 'coming_soon' ? 'selected' : ''}>Coming soon</option><option value="completed" ${p.status === 'completed' ? 'selected' : ''}>Completed</option></select></label><div class="full-width"><div class="field-caption">Cover image</div><button type="button" class="project-cover" id="project-cover" data-pick-cover style="margin-top:10px">${p.cover ? `<img src="${esc(imageSrc(p.cover))}" alt="Project cover">` : icon('image')}<span>${p.cover ? 'Change cover image' : 'Choose a cover image'}</span></button></div><label class="full-width">Short description<textarea name="summary" aria-label="Short description" maxlength="700" rows="2" placeholder="A short introduction for the project card.">${esc(p.summary)}</textarea></label><label class="full-width">Project description<textarea name="description" aria-label="Project description" maxlength="8000" rows="5" placeholder="Share the location, vision, progress and details of this project.">${esc(p.description)}</textarea></label><div class="full-width"><div class="field-caption">Project gallery <button class="button button--small" type="button" data-pick-gallery>${icon('plus')} Add photos</button></div><div class="gallery-grid" id="project-gallery"></div><p class="field-help" style="margin-top:10px">Add up to 12 photos. The cover image is also shown in the project gallery.</p></div><label class="full-width">Project highlights<textarea name="features" aria-label="Project highlights" rows="4" placeholder="Gated entrance&#10;Landscaped avenues&#10;Water and electricity connections">${esc(p.features.join('\n'))}</textarea><span class="field-help">One highlight per line, up to 12.</span></label><label class="check-label full-width"><input type="checkbox" name="visible" ${p.visible ? 'checked' : ''}><span>Show this project on the website</span></label><label class="check-label full-width"><input type="checkbox" name="featured" ${p.featured ? 'checked' : ''}><span>Feature this project on the home page<span class="field-help" style="display:block">This replaces the current featured project.</span></span></label></div>`, `${found ? '<button class="button button--danger" type="button" data-archive-project>Archive project</button>' : '<span></span>'}<div class="dialog-footer-actions"><button class="button" type="button" data-close-editor>Cancel</button><button class="button button--primary" type="submit">Save project</button></div>`, 'project-form');
    renderGallery();
    $('#project-form').onsubmit = event => {
      event.preventDefault(); const values = new FormData(event.currentTarget);
      if (!editingProject.cover) { $('#editor-error').textContent = 'Choose a cover image for this project.'; return; }
      const features = String(values.get('features')).split('\n').map(value => value.trim()).filter(Boolean);
      if (features.length > 12) { $('#editor-error').textContent = 'Use up to 12 project highlights.'; return; }
      for (const key of ['title','location','category','status','summary','description']) editingProject[key] = String(values.get(key)).trim();
      editingProject.visible = values.has('visible'); editingProject.featured = values.has('featured') && editingProject.visible; editingProject.features = features;
      if (editingProject.featured) for (const project of S.draft.projects) project.featured = false;
      const index = S.draft.projects.findIndex(project => project.id === editingProject.id);
      if (index >= 0) S.draft.projects[index] = clone(editingProject); else S.draft.projects.unshift(clone(editingProject));
      markDirty(); editor.close(); renderMain(); toast('Project saved in your draft.');
    };
  }

  function renderGallery() {
    $('#project-gallery').innerHTML = editingProject.gallery.map((src,index) => `<div class="gallery-item"><img src="${esc(imageSrc(src))}" alt="Gallery photo ${index + 1}"><button type="button" data-remove-gallery="${index}" aria-label="Remove gallery photo ${index + 1}">×</button></div>`).join('');
  }

  function pickMedia(callback, multiple = false) {
    mediaCallback = callback; mediaMultiple = multiple; picked = new Set(); pickerTab = S.media.length ? 'uploads' : 'website';
    picker.innerHTML = `<div class="dialog-header"><div><h2 id="picker-title">Choose ${multiple ? 'gallery photos' : 'an image'}</h2><p>Use a photo from your collection or upload a new one.</p></div><button class="icon-button" data-close-picker aria-label="Close image library">${icon('close')}</button></div><div class="picker-body"><div class="error-message" id="picker-error" role="alert"></div><div class="picker-toolbar"><div class="tabs"><button class="tab" data-picker-tab="uploads">Uploads</button><button class="tab" data-picker-tab="website">Website images</button></div><label class="button button--small upload-button">${icon('upload')} Upload ${multiple ? 'photos' : 'image'}<input type="file" accept="image/jpeg,image/png,image/webp,image/avif" ${multiple ? 'multiple' : ''} data-upload="picker"></label></div><div class="picker-grid" id="picker-grid"></div></div>${multiple ? '<div class="dialog-footer"><p class="field-help" id="picked-count">No photos selected</p><div class="dialog-footer-actions"><button class="button" data-close-picker>Cancel</button><button class="button button--primary" data-use-picked>Use selected photos</button></div></div>' : ''}`;
    renderPicker(); picker.showModal();
  }

  function renderPicker() {
    for (const tab of picker.querySelectorAll('[data-picker-tab]')) tab.classList.toggle('is-active', tab.dataset.pickerTab === pickerTab);
    const images = pickerTab === 'uploads' ? S.media.map(item => ({src:item.src,label:item.name})) : S.catalogue.map(item => ({src:item.src,label:item.label}));
    $('#picker-grid').innerHTML = images.length ? images.map(item => `<button type="button" class="picker-item ${picked.has(item.src) ? 'is-selected' : ''}" data-select-media="${esc(item.src)}"><img src="${esc(imageSrc(item.src))}" alt="${esc(item.label)}" loading="lazy"><span>${esc(item.label)}</span></button>`).join('') : empty('media','No uploaded photos yet','Use Upload image to add your first photo.');
    if ($('#picked-count')) $('#picked-count').textContent = picked.size ? `${picked.size} ${picked.size === 1 ? 'photo' : 'photos'} selected` : 'No photos selected';
  }

  async function upload(files) {
    const results = [];
    for (const file of files) {
      if (file.size > 10485760) throw new Error('Each image must be 10 MB or smaller.');
      const form = new FormData(); form.append('image', file);
      const item = await api('upload', form); S.media.unshift(item); results.push(item);
    }
    return results;
  }

  async function saveDraft() {
    if (!S.dirty) return;
    const response = await api('save', {baseRevision:S.draft.revision,content:{images:S.draft.images,projects:S.draft.projects}});
    S.draft = response.draft; S.draft.images = {...S.draft.images}; S.dirty = false; updateHeader();
  }

  async function persist(publish) {
    if (S.busy) return;
    S.busy = true; updateHeader();
    try {
      await saveDraft();
      if (publish) {
        const result = await api('publish', {revision:S.draft.revision}); S.draft = result.published; S.draft.images = {...S.draft.images}; S.publishedRevision = S.draft.revision; S.publishedAt = S.draft.publishedAt;
        toast('Published. Your website is up to date.');
      } else toast('Your draft is saved.');
      renderMain();
    } catch (error) { toast(error.message, true); }
    finally { S.busy = false; updateHeader(); }
  }

  function passwordEditor() {
    openEditor('Change password', 'Choose a new password for your owner login.', '<div class="field-stack"><label>Current password<input type="password" name="currentPassword" autocomplete="current-password" required></label><label>New password<input type="password" name="password" autocomplete="new-password" required minlength="12" maxlength="72"></label><label>Confirm new password<input type="password" name="confirmPassword" autocomplete="new-password" required minlength="12" maxlength="72"></label><p class="field-help">Use a unique password with at least 12 characters.</p></div>', '<div class="dialog-footer-actions"><button class="button" type="button" data-close-editor>Cancel</button><button class="button button--primary" type="submit">Change password</button></div>', 'password-form');
    $('#password-form').onsubmit = async event => {
      event.preventDefault(); const data = new FormData(event.currentTarget);
      if (data.get('password') !== data.get('confirmPassword')) { $('#editor-error').textContent = 'The passwords do not match.'; return; }
      try { const result = await api('password',{currentPassword:data.get('currentPassword'),password:data.get('password')}); S.csrf = result.csrf; editor.close(); toast('Password updated.'); }
      catch (error) { $('#editor-error').textContent = error.message; }
    };
  }

  document.addEventListener('click', async event => {
    const target = event.target.closest('button,a'); if (!target) return;
    if (target.dataset.nav) { S.section = target.dataset.nav; history.replaceState(null, '', '#' + S.section); renderMain(); window.scrollTo({top:0,behavior:'instant'}); }
    if (target.dataset.editImage) editImage(target.dataset.editImage);
    if (target.dataset.resetImage) { const id = target.dataset.resetImage, previous = clone(S.draft.images[id]); delete S.draft.images[id]; markDirty(); renderMain(); toast('Original image restored in your draft.',false,()=>{S.draft.images[id]=previous;markDirty();renderMain();}); }
    if (target.dataset.editProject) editProject(target.dataset.editProject);
    if (target.dataset.projectFilter) { S.projectFilter = target.dataset.projectFilter; renderProjects(); }
    if (target.dataset.restoreProject) { const p = S.draft.projects.find(p => p.id === target.dataset.restoreProject); p.archived = false; markDirty(); renderMain(); toast('Project restored in your draft.'); }
    if (target.hasAttribute('data-close-editor')) editor.close();
    if (target.hasAttribute('data-close-picker')) picker.close();
    if (target.hasAttribute('data-pick-image')) pickMedia(src => { editingImage.src = src; $('#image-preview').src = src; });
    if (target.hasAttribute('data-pick-cover')) pickMedia(src => { editingProject.cover = src; $('#project-cover').innerHTML = `<img src="${esc(imageSrc(src))}" alt="Project cover"><span>Change cover image</span>`; });
    if (target.hasAttribute('data-pick-gallery')) pickMedia(sources => { editingProject.gallery = [...new Set([...editingProject.gallery,...sources])].slice(0,12); renderGallery(); },true);
    if (target.dataset.removeGallery !== undefined) { editingProject.gallery.splice(Number(target.dataset.removeGallery),1);renderGallery(); }
    if (target.dataset.pickerTab) { pickerTab = target.dataset.pickerTab; renderPicker(); }
    if (target.dataset.selectMedia) {
      const src = target.dataset.selectMedia;
      if (mediaMultiple) { if (picked.has(src)) picked.delete(src); else if (picked.size < 12) picked.add(src); renderPicker(); }
      else { mediaCallback(src); picker.close(); }
    }
    if (target.hasAttribute('data-use-picked')) { if (!picked.size) { $('#picker-error').textContent = 'Choose at least one photo.'; return; } mediaCallback([...picked]); picker.close(); }
    if (target.hasAttribute('data-archive-project')) {
      const id = editingProject.id, previous = clone(S.draft.projects.find(item=>item.id===id)), p = S.draft.projects.find(item=>item.id===id);
      p.archived = true; p.featured = false; markDirty(); editor.close(); renderMain();
      toast('Project moved to the archive.',false,()=>{S.draft.projects[S.draft.projects.findIndex(item=>item.id===id)]=previous;markDirty();renderMain();});
    }
    if (target.dataset.action === 'add-project') editProject(null);
    if (target.dataset.action === 'save') await persist(false);
    if (target.dataset.action === 'publish') await persist(true);
    if (target.dataset.action === 'password') passwordEditor();
    if (target.dataset.action === 'logout') {
      try { if (S.dirty) await saveDraft(); await api('logout',{}); S.session = await api('session'); S.csrf = S.session.csrf; authScreen(); }
      catch (error) { toast(error.message,true); }
    }
  });

  document.addEventListener('change', async event => {
    const input = event.target;
    if (!input.matches('input[data-upload]') || !input.files.length) return;
    const where = input.dataset.upload; input.disabled = true;
    try {
      toast('Uploading your photos…'); const results = await upload([...input.files]);
      if (where === 'image') { editingImage.src = results[0].src; $('#image-preview').src = results[0].src; }
      if (where === 'picker') {
        pickerTab = 'uploads';
        if (mediaMultiple) { for (const item of results) if (picked.size < 12) picked.add(item.src); renderPicker(); }
        else { mediaCallback(results[0].src); picker.close(); }
      }
      if (where === 'library') renderMedia();
      toast(results.length === 1 ? 'Image uploaded.' : `${results.length} images uploaded.`);
    } catch (error) {
      const box = where === 'picker' ? $('#picker-error') : editor.open ? $('#editor-error') : null;
      if (box) box.textContent = error.message; else toast(error.message,true);
    } finally { input.disabled = false; input.value = ''; }
  });

  addEventListener('beforeunload', event => { if (S.dirty) { event.preventDefault(); event.returnValue = ''; } });
  addEventListener('hashchange',()=>{const section=location.hash.slice(1);if(S.draft&&['overview','images','projects','media'].includes(section)){S.section=section;renderMain();}});
  (async()=>{try{S.session=await api('session');S.csrf=S.session.csrf;if(S.session.authenticated)await loadWorkspace();else authScreen();}catch(error){$('#app').innerHTML=`<div class="loading-screen"><span class="brand-mark">MV</span><p>${esc(error.message)}</p><button class="button" id="retry">Try again</button></div>`;$('#retry').onclick=()=>location.reload();}})();
})();
