<?php
declare(strict_types=1);

final class CmsError extends RuntimeException {
    public int $status;
    public function __construct(int $status, string $message) { parent::__construct($message); $this->status = $status; }
}

function cms_json(array $value, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($value, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    exit;
}

function cms_storage(): string {
    static $root;
    if ($root !== null) return $root;
    $root = getenv('MALGHE_CMS_STORAGE') ?: dirname(__DIR__, 2) . '/.malghe-cms';
    if (!is_dir($root) && !mkdir($root, 0700, true) && !is_dir($root)) throw new RuntimeException('Cannot create content storage');
    $real = realpath($root);
    $web = realpath(dirname(__DIR__));
    if (!$real || !$web || $real === $web || str_starts_with($real, $web . DIRECTORY_SEPARATOR)) throw new RuntimeException('Content storage must be outside the public website');
    $root = $real;
    foreach (['media', 'sessions', 'history'] as $dir) if (!is_dir($root . '/' . $dir)) mkdir($root . '/' . $dir, 0700);
    return $root;
}

function cms_read(string $name, mixed $default = null): mixed {
    $path = cms_storage() . '/' . $name;
    return is_file($path) ? json_decode(file_get_contents($path), true, 64, JSON_THROW_ON_ERROR) : $default;
}

function cms_write(string $name, mixed $value): void {
    $path = cms_storage() . '/' . $name;
    $temp = tempnam(dirname($path), '.write-');
    try {
        if (file_put_contents($temp, json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)) === false) throw new RuntimeException('Cannot save content');
        chmod($temp, 0600);
        if (!rename($temp, $path)) throw new RuntimeException('Cannot replace content');
    } finally { if (is_file($temp)) unlink($temp); }
}

function cms_locked(callable $fn): mixed {
    $file = fopen(cms_storage() . '/.lock', 'c');
    if (!$file || !flock($file, LOCK_EX)) throw new RuntimeException('Cannot lock content');
    try { return $fn(); } finally { flock($file, LOCK_UN); fclose($file); }
}

function cms_seed(): array { return json_decode(file_get_contents(__DIR__ . '/seed.json'), true, 64, JSON_THROW_ON_ERROR); }
function cms_published(): array { return cms_read('published.json', cms_seed()); }
function cms_public_content(): array {
    $content = cms_published();
    $content['projects'] = array_values(array_filter($content['projects'], fn($project) => !empty($project['visible']) && empty($project['archived'])));
    return $content;
}
function cms_draft(): array { return cms_read('draft.json', cms_published()); }
function cms_catalogue(): array { return json_decode(file_get_contents(__DIR__ . '/catalogue.json'), true, 64, JSON_THROW_ON_ERROR); }

function cms_setup_hash(): string {
    $configured = getenv('MALGHE_CMS_SETUP_HASH');
    if ($configured !== false && $configured !== '') return $configured;
    $config = is_file(__DIR__ . '/config.php') ? require __DIR__ . '/config.php' : [];
    return $config['setup_token_hash'] ?? '';
}

function cms_session(): void {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');
    ini_set('session.gc_maxlifetime', '43200');
    ini_set('session.save_path', cms_storage() . '/sessions');
    session_name('MALGHE_OWNER');
    $host = strtolower($_SERVER['HTTP_HOST'] ?? '');
    $local = preg_match('/^(localhost|127\.0\.0\.1|\[::1\])(?::[0-9]+)?$/D', $host) === 1;
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => !$local || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'), 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
    if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    if (isset($_SESSION['owner']) && (time() - ($_SESSION['seen'] ?? 0) > 3600 || time() - ($_SESSION['started'] ?? 0) > 43200)) unset($_SESSION['owner']);
    if (isset($_SESSION['owner'])) {
        $owner = cms_read('owner.json');
        if (!$owner || !hash_equals($owner['authVersion'] ?? '', $_SESSION['authVersion'] ?? 'invalid')) unset($_SESSION['owner']);
    }
    if (isset($_SESSION['owner'])) $_SESSION['seen'] = time();
}

function cms_authenticated(): void { if (empty($_SESSION['owner'])) throw new CmsError(401, 'Please sign in to continue.'); }

function cms_csrf(): void {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        $parts = parse_url($origin);
        $host = ($parts['host'] ?? '') . (isset($parts['port']) ? ':' . $parts['port'] : '');
        if (strtolower($host) !== strtolower($_SERVER['HTTP_HOST'] ?? '')) throw new CmsError(403, 'This request must come from your website.');
    }
    if (($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') === 'cross-site') throw new CmsError(403, 'Cross-site requests are not allowed.');
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['csrf'], $token)) throw new CmsError(403, 'Your session expired. Refresh the page and try again.');
}

function cms_body(): array {
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 2097152) throw new CmsError(413, 'This request is too large.');
    try { $body = json_decode(file_get_contents('php://input'), true, 32, JSON_THROW_ON_ERROR); }
    catch (JsonException $e) { throw new CmsError(400, 'Please send valid JSON.'); }
    if (!is_array($body)) throw new CmsError(400, 'The request is not valid.');
    return $body;
}

function cms_text(mixed $value, int $max, string $label, bool $required = false): string {
    if (!is_string($value)) throw new CmsError(422, $label . ' must be text.');
    $value = trim(str_replace("\0", '', $value));
    if (strlen($value) > $max || ($required && $value === '')) throw new CmsError(422, $label . ' is missing or too long.');
    return $value;
}

function cms_password(mixed $password): string {
    if (!is_string($password) || strlen($password) < 12 || strlen($password) > 72 || str_contains($password, "\0")) throw new CmsError(422, 'Use a password between 12 and 72 characters.');
    return $password;
}

function cms_rate(string $kind, bool $failed = false, bool $clear = false): void {
    $key = hash('sha256', $kind . ':' . ($_SERVER['REMOTE_ADDR'] ?? 'local'));
    cms_locked(function () use ($key, $failed, $clear) {
        $all = cms_read('rate-limits.json', []);
        $now = time();
        foreach ($all as $id => $record) if (($record['until'] ?? 0) < $now) unset($all[$id]);
        $record = $all[$key] ?? ['count' => 0, 'until' => $now + 900];
        if (!$clear && $record['count'] >= 8) { header('Retry-After: 900'); throw new CmsError(429, 'Too many attempts. Please wait 15 minutes and try again.'); }
        if ($clear) unset($all[$key]);
        elseif ($failed) { $record['count']++; $all[$key] = $record; }
        cms_write('rate-limits.json', $all);
    });
}

function cms_image(string $src): string {
    static $known;
    if ($known === null) $known = array_fill_keys(array_column(cms_catalogue()['images'], 'id'), true);
    if (isset($known[$src])) return $src;
    if (preg_match('~^/cms/media\.php\?file=([a-f0-9]{32}\.(?:jpg|png|webp|avif))$~D', $src, $match) && is_file(cms_storage() . '/media/' . $match[1])) return $src;
    throw new CmsError(422, 'Choose an image from the website or media library.');
}

function cms_validate_content(array $body): array {
    $images = $body['images'] ?? [];
    $projects = $body['projects'] ?? [];
    if (!is_array($images) || !is_array($projects) || count($images) > 300 || count($projects) > 100) throw new CmsError(422, 'There are too many images or projects.');
    $known = array_fill_keys(array_column(cms_catalogue()['images'], 'id'), true);
    $cleanImages = [];
    foreach ($images as $id => $image) {
        if (!isset($known[$id]) || !is_array($image)) throw new CmsError(422, 'This website image is not recognised.');
        $focusX = $image['focusX'] ?? 50; $focusY = $image['focusY'] ?? 50;
        if (!is_numeric($focusX) || !is_numeric($focusY) || $focusX < 0 || $focusX > 100 || $focusY < 0 || $focusY > 100) throw new CmsError(422, 'Image focus must be between 0 and 100.');
        $cleanImages[$id] = ['src' => cms_image(cms_text($image['src'] ?? '', 300, 'Image', true)), 'alt' => cms_text($image['alt'] ?? '', 500, 'Image description'), 'focusX' => (float)$focusX, 'focusY' => (float)$focusY];
    }
    $cleanProjects = []; $ids = []; $featured = 0;
    foreach ($projects as $project) {
        if (!is_array($project)) throw new CmsError(422, 'A project is not valid.');
        $id = cms_text($project['id'] ?? '', 80, 'Project ID', true);
        if (!preg_match('/^[a-z0-9][a-z0-9-]{1,79}$/D', $id) || isset($ids[$id])) throw new CmsError(422, 'Each project must have a unique ID.');
        $ids[$id] = true;
        $status = $project['status'] ?? '';
        if (!in_array($status, ['coming_soon', 'completed'], true)) throw new CmsError(422, 'Choose Coming soon or Completed.');
        $category = cms_text($project['category'] ?? '', 80, 'Project type', true);
        if (!in_array($category, ['Premium plotting', 'Construction', 'Interiors', 'Real estate'], true)) throw new CmsError(422, 'Choose a project type.');
        $gallery = $project['gallery'] ?? []; $features = $project['features'] ?? [];
        if (!is_array($gallery) || count($gallery) > 12 || !is_array($features) || count($features) > 12) throw new CmsError(422, 'Use up to 12 gallery images and 12 project highlights.');
        $cleanGallery = [];
        foreach ($gallery as $src) $cleanGallery[] = cms_image(cms_text($src, 300, 'Gallery image', true));
        $cleanFeatures = [];
        foreach ($features as $feature) { $text = cms_text($feature, 200, 'Project highlight'); if ($text !== '') $cleanFeatures[] = $text; }
        $archived = (bool)($project['archived'] ?? false);
        $visible = (bool)($project['visible'] ?? true);
        $isFeatured = (bool)($project['featured'] ?? false) && !$archived && $visible;
        if ($isFeatured) $featured++;
        $cleanProjects[] = ['id' => $id, 'title' => cms_text($project['title'] ?? '', 160, 'Project name', true), 'location' => cms_text($project['location'] ?? '', 160, 'Location', true), 'category' => $category, 'status' => $status, 'summary' => cms_text($project['summary'] ?? '', 700, 'Short description'), 'description' => cms_text($project['description'] ?? '', 8000, 'Project description'), 'cover' => cms_image(cms_text($project['cover'] ?? '', 300, 'Cover image', true)), 'gallery' => array_values(array_unique($cleanGallery)), 'features' => $cleanFeatures, 'visible' => $visible, 'archived' => $archived, 'featured' => $isFeatured];
    }
    if ($featured > 1) throw new CmsError(422, 'Only one project can be featured on the home page.');
    return ['images' => $cleanImages, 'projects' => $cleanProjects];
}

function cms_audit(string $event): void {
    file_put_contents(cms_storage() . '/activity.log', json_encode(['at' => gmdate('c'), 'event' => $event, 'owner' => $_SESSION['owner'] ?? null], JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);
}
