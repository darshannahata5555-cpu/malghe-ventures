<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';

try {
    $action = $_GET['action'] ?? 'content';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method === 'GET' && $action === 'content') cms_json(cms_public_content());
    cms_session();
    if ($method === 'GET' && $action === 'session') cms_json(['authenticated' => isset($_SESSION['owner']), 'username' => $_SESSION['owner'] ?? null, 'csrf' => $_SESSION['csrf'], 'needsSetup' => !is_file(cms_storage() . '/owner.json'), 'setupAvailable' => cms_setup_hash() !== '']);
    if ($method === 'GET') {
        cms_authenticated();
        if ($action === 'preview') cms_json(cms_draft());
        if ($action === 'draft') cms_json(['draft' => cms_draft(), 'publishedRevision' => cms_published()['revision'], 'publishedAt' => cms_published()['publishedAt'] ?? null, 'catalogue' => cms_catalogue()]);
        if ($action === 'media') {
            $items = [];
            foreach (glob(cms_storage() . '/media/*.json') ?: [] as $file) $items[] = json_decode(file_get_contents($file), true, 16, JSON_THROW_ON_ERROR);
            usort($items, fn($a, $b) => strcmp($b['createdAt'], $a['createdAt']));
            cms_json(['items' => $items]);
        }
        throw new CmsError(404, 'This action was not found.');
    }
    if ($method !== 'POST') throw new CmsError(405, 'This method is not supported.');
    cms_csrf();
    if ($action === 'setup') {
        cms_rate('setup');
        if (is_file(cms_storage() . '/owner.json')) throw new CmsError(409, 'The owner account has already been created.');
        $hash = cms_setup_hash(); $key = $_SERVER['HTTP_X_SETUP_KEY'] ?? '';
        if ($hash === '' || !is_string($key) || !hash_equals($hash, hash('sha256', $key))) { cms_rate('setup', true); throw new CmsError(403, 'Open your private setup link to create the owner account.'); }
        $body = cms_body(); $username = cms_text($body['username'] ?? '', 80, 'Username', true);
        if (!preg_match('/^[a-zA-Z0-9@._+-]{3,80}$/D', $username)) throw new CmsError(422, 'Use 3–80 letters, numbers, or email-address characters for the username.');
        $password = cms_password($body['password'] ?? null);
        cms_locked(function () use ($username, $password) {
            if (is_file(cms_storage() . '/owner.json')) throw new CmsError(409, 'The owner account already exists.');
            cms_write('owner.json', ['username' => $username, 'passwordHash' => password_hash($password, PASSWORD_DEFAULT), 'authVersion' => bin2hex(random_bytes(16)), 'createdAt' => gmdate('c')]);
        });
        session_regenerate_id(true); $_SESSION['owner'] = $username; $_SESSION['started'] = $_SESSION['seen'] = time(); $_SESSION['csrf'] = bin2hex(random_bytes(32));
        $_SESSION['authVersion'] = cms_read('owner.json')['authVersion'];
        cms_rate('setup', false, true); cms_audit('owner-created');
        cms_json(['ok' => true, 'csrf' => $_SESSION['csrf'], 'username' => $username], 201);
    }
    if ($action === 'login') {
        cms_rate('login'); $body = cms_body(); $owner = cms_read('owner.json');
        $username = is_string($body['username'] ?? null) ? $body['username'] : '';
        $password = is_string($body['password'] ?? null) ? $body['password'] : '';
        if (!$owner || !hash_equals(strtolower($owner['username']), strtolower($username)) || !password_verify($password, $owner['passwordHash'])) { cms_rate('login', true); throw new CmsError(401, 'Username or password is incorrect.'); }
        session_regenerate_id(true); $_SESSION['owner'] = $owner['username']; $_SESSION['started'] = $_SESSION['seen'] = time(); $_SESSION['csrf'] = bin2hex(random_bytes(32));
        $_SESSION['authVersion'] = $owner['authVersion'];
        cms_rate('login', false, true); cms_audit('signed-in');
        cms_json(['ok' => true, 'csrf' => $_SESSION['csrf'], 'username' => $owner['username']]);
    }
    cms_authenticated();
    if ($action === 'logout') { cms_audit('signed-out'); $_SESSION = []; session_destroy(); setcookie(session_name(), '', ['expires' => time() - 3600, 'path' => '/', 'httponly' => true, 'samesite' => 'Strict']); cms_json(['ok' => true]); }
    if ($action === 'password') {
        cms_rate('password');
        $body = cms_body(); $password = cms_password($body['password'] ?? null); $owner = cms_read('owner.json');
        if (!is_string($body['currentPassword'] ?? null) || !password_verify($body['currentPassword'], $owner['passwordHash'])) { cms_rate('password', true); throw new CmsError(403, 'The current password is incorrect.'); }
        $owner['passwordHash'] = password_hash($password, PASSWORD_DEFAULT); $owner['authVersion'] = bin2hex(random_bytes(16));
        cms_locked(fn() => cms_write('owner.json', $owner)); session_regenerate_id(true); $_SESSION['authVersion'] = $owner['authVersion'];
        $_SESSION['csrf'] = bin2hex(random_bytes(32)); cms_rate('password', false, true); cms_audit('password-changed'); cms_json(['ok' => true, 'csrf' => $_SESSION['csrf']]);
    }
    if ($action === 'upload') {
        $file = $_FILES['image'] ?? null;
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) throw new CmsError(422, 'Choose an image up to 10 MB and try again.');
        if ($file['size'] > 10485760 || !is_uploaded_file($file['tmp_name'])) throw new CmsError(413, 'Images must be 10 MB or smaller.');
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        $types = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/avif' => 'avif'];
        $size = @getimagesize($file['tmp_name']);
        if (!isset($types[$mime]) || !$size || $size[0] > 10000 || $size[1] > 10000 || $size[0] * $size[1] > 40000000) throw new CmsError(422, 'Upload a valid JPG, PNG, WebP or AVIF image, up to 40 megapixels.');
        $id = bin2hex(random_bytes(16)) . '.' . $types[$mime];
        $destination = cms_storage() . '/media/' . $id;
        if (!move_uploaded_file($file['tmp_name'], $destination)) throw new RuntimeException('Cannot save image');
        chmod($destination, 0600);
        $item = ['id' => $id, 'src' => '/cms/media.php?file=' . $id, 'name' => cms_text(basename($file['name']), 250, 'Filename'), 'width' => $size[0], 'height' => $size[1], 'bytes' => $file['size'], 'createdAt' => gmdate('c')];
        cms_write('media/' . $id . '.json', $item); cms_audit('image-uploaded'); cms_json($item, 201);
    }
    if ($action === 'save') {
        $body = cms_body();
        if (!is_array($body['content'] ?? null)) throw new CmsError(422, 'The draft content is not valid.');
        $clean = cms_validate_content($body['content']);
        $draft = cms_locked(function () use ($body, $clean) {
            $current = cms_draft();
            if (!isset($body['baseRevision']) || (int)$body['baseRevision'] !== (int)$current['revision']) throw new CmsError(409, 'A newer draft exists. Reload the draft before making more changes.');
            $next = $clean + ['revision' => $current['revision'] + 1, 'updatedAt' => gmdate('c'), 'publishedAt' => $current['publishedAt'] ?? null];
            cms_write('draft.json', $next); return $next;
        });
        cms_audit('draft-saved'); cms_json(['draft' => $draft]);
    }
    if ($action === 'publish') {
        $body = cms_body();
        $published = cms_locked(function () use ($body) {
            $draft = cms_draft();
            if (!isset($body['revision']) || (int)$body['revision'] !== (int)$draft['revision']) throw new CmsError(409, 'The draft changed. Reload it before publishing.');
            cms_validate_content($draft);
            $previous = cms_published();
            cms_write('history/' . time() . '-' . $previous['revision'] . '.json', $previous);
            $history = glob(cms_storage() . '/history/*.json') ?: []; rsort($history);
            foreach (array_slice($history, 20) as $file) unlink($file);
            $draft['publishedAt'] = gmdate('c'); cms_write('published.json', $draft); cms_write('draft.json', $draft); return $draft;
        });
        cms_audit('changes-published'); cms_json(['published' => $published]);
    }
    throw new CmsError(404, 'This action was not found.');
} catch (CmsError $e) { cms_json(['error' => $e->getMessage()], $e->status); }
catch (Throwable $e) { error_log('Malghe CMS: ' . $e->getMessage()); cms_json(['error' => 'The change could not be saved. Please try again.'], 500); }
