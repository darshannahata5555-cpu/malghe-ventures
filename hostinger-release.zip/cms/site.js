(() => {
  'use strict';
  if (window.MalgheCMS) return;
  window.MalgheCMS = true;
  const preview = new URLSearchParams(location.search).get('cms_preview') === '1';
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeImage = value => typeof value === 'string' && (/^\/img\/[a-zA-Z0-9._-]+$/.test(value) || /^\/cms\/media\.php\?file=[a-f0-9]{32}\.(jpg|png|webp|avif)$/.test(value)) ? value : '/img/office-logo.webp';
  const path = value => { try { return new URL(value, location.origin).pathname.replace(/^\/malghe-ventures(?=\/)/, ''); } catch { return ''; } };
  const originalImages = new WeakMap();
  let content = null, queued = false, loadedAt = 0, requestedProject = null, hydrationTimer = null, loading = false, lastPath = location.pathname;
  const status = project => project.status === 'completed' ? 'Completed' : 'Coming soon';
  const visibleProjects = () => (content?.projects || []).filter(project => project.visible && !project.archived);
  const imageTag = (src, alt, extra = '') => `<img src="${escape(safeImage(src))}" alt="${escape(alt)}" loading="lazy" decoding="async" ${extra}>`;

  function applyImages() {
    for (const img of document.querySelectorAll('img')) {
      const current = img.getAttribute('src') || '';
      let record = originalImages.get(img);
      if (!record || (path(current).startsWith('/img/') && current !== record.applied && path(current) !== record.id)) {
        record = {id: path(current), src: current, srcset: img.getAttribute('srcset'), alt: img.getAttribute('alt'), focus: img.style.objectPosition, applied: null};
        originalImages.set(img, record);
      }
      const replacement = content?.images?.[record.id];
      if (replacement) {
        const src = safeImage(replacement.src);
        if (img.getAttribute('src') !== src) img.setAttribute('src', src);
        if (img.hasAttribute('srcset')) img.removeAttribute('srcset');
        if (img.alt !== replacement.alt) img.alt = replacement.alt || '';
        const focus = `${replacement.focusX ?? 50}% ${replacement.focusY ?? 50}%`;
        if (img.style.objectPosition !== focus) img.style.objectPosition = focus;
        record.applied = src;
      } else if (record.applied) {
        img.setAttribute('src', record.src);
        if (record.srcset !== null) img.setAttribute('srcset', record.srcset); else img.removeAttribute('srcset');
        if (record.alt !== null) img.setAttribute('alt', record.alt);
        img.style.objectPosition = record.focus;
        record.applied = null;
      }
    }
  }

  function enquiry(project) {
    return 'https://wa.me/917796484545?text=' + encodeURIComponent(`Hello Malghe Ventures, I'd like to know more about ${project.title}.`);
  }

  function gallery(project) { return [...new Set([project.cover, ...(project.gallery || [])])].filter(Boolean); }

  function feature(project) {
    const images = gallery(project);
    return `<section class="dc section cms-feature" data-cms-owned="feature"><div class="wrap dc__head"><p class="dc__kicker">Featured project</p><h2 class="dc__title">${escape(project.title)}${project.location ? ', ' + escape(project.location.split(',')[0]) : ''}</h2><p class="dc__intro">${escape(project.summary)}</p></div><div class="wrap dc__grid"><div class="dc__gallery"><div class="dc__stage cms-feature-stage">${imageTag(images[0], project.title, 'data-cms-feature-image')}<span class="cms-project-status">${status(project)}</span></div><div class="dc__thumbs">${images.map((src, i) => `<button type="button" class="dc__thumb ${i === 0 ? 'is-active' : ''}" aria-label="View ${escape(project.title)} image ${i + 1}" data-cms-gallery="${escape(project.id)}" data-index="${i}">${imageTag(src, '')}</button>`).join('')}</div></div><aside><dl class="dc__facts"><div><dt>Location</dt><dd>${escape(project.location)}</dd></div><div><dt>Project</dt><dd>${escape(project.category)}</dd></div><div><dt>Status</dt><dd>${status(project)}</dd></div></dl>${project.description ? `<p class="cms-feature-description">${escape(project.description)}</p>` : ''}<ul class="dc__features">${(project.features || []).map(item => `<li><span aria-hidden="true">✓</span>${escape(item)}</li>`).join('')}</ul><div class="dc__actions"><a class="cms-site-button" href="/projects/?project=${encodeURIComponent(project.id)}">View project <span aria-hidden="true">↗</span></a><a class="cms-site-button cms-site-button--outline" href="${escape(enquiry(project))}">Enquire on WhatsApp</a></div></aside></div></section>`;
  }

  function cards(projects, heading, intro) {
    return `<section class="section cms-project-section" data-cms-owned="projects"><div class="wrap"><header class="up__head"><h2 class="h2">${heading}</h2><p>${intro}</p></header>${projects.length ? `<ul class="up__grid cms-project-grid">${projects.map(project => `<li class="up__card"><button type="button" class="cms-project-open" data-cms-open-project="${escape(project.id)}" aria-label="View ${escape(project.title)}"><div class="up__media cms-project-media">${imageTag(project.cover, project.title)}<span class="up__tag">${status(project)}</span></div><div class="up__meta"><small>${escape(project.category)}</small><h3>${escape(project.title)}</h3><p>${escape(project.location)}</p>${project.summary ? `<p class="cms-card-summary">${escape(project.summary)}</p>` : ''}<span class="cms-view-project">View project <span aria-hidden="true">↗</span></span></div></button></li>`).join('')}</ul>` : '<p class="cms-project-empty">New projects will be shared here.</p>'}</div></section>`;
  }

  function renderProjects() {
    const route = location.pathname.replace(/^\/malghe-ventures(?=\/)/, '').replace(/\/+$/, '') || '/';
    const scope = route === '/' ? 'home' : route === '/projects' ? 'projects' : '';
    if (scope !== 'home') delete document.documentElement.dataset.cmsNoProjects;
    const main = document.querySelector('#main');
    const oldMount = document.querySelector('[data-cms-project-mount]');
    if (!scope || !main || !Array.isArray(content?.projects)) {
      oldMount?.remove(); delete document.documentElement.dataset.cmsProjects;
      return;
    }
    const signature = scope + ':' + content.revision;
    let mount = oldMount;
    if (!mount || mount.parentElement !== main) {
      mount?.remove(); mount = document.createElement('div'); mount.dataset.cmsProjectMount = '';
      const anchor = main.querySelector(':scope > .dc, :scope > .up, :scope > .visit');
      if (!anchor) return;
      main.insertBefore(mount, anchor);
    }
    if (mount.dataset.revision !== signature) {
      const projects = visibleProjects();
      if (scope === 'home') {
        const selected = projects.find(project => project.featured) || projects.find(project => project.status === 'completed') || projects[0];
        mount.innerHTML = selected ? feature(selected) : '';
        if (!selected) {
          document.documentElement.dataset.cmsProjects = scope;
          document.documentElement.dataset.cmsNoProjects = 'true';
          mount.dataset.revision = signature;
          return;
        }
        delete document.documentElement.dataset.cmsNoProjects;
        const heroLink = document.querySelector('.hero__card');
        if (heroLink) {
          heroLink.href = '/projects/?project=' + encodeURIComponent(selected.id);
          const title = heroLink.querySelector('strong'); if (title && title.textContent !== selected.title) title.textContent = selected.title;
          const img = heroLink.querySelector('img'); if (img && img.getAttribute('src') !== selected.cover) { originalImages.delete(img); img.setAttribute('src', safeImage(selected.cover)); img.removeAttribute('srcset'); }
        }
      } else mount.innerHTML = cards(projects.filter(p => p.status === 'completed'), 'Completed projects', 'Explore the developments delivered by Malghe Ventures.') + cards(projects.filter(p => p.status === 'coming_soon'), 'Coming soon', 'Discover our upcoming layouts, homes and interiors.');
      mount.dataset.revision = signature;
      setTimeout(() => window.dispatchEvent(new Event('resize')), 0);
    }
    document.documentElement.dataset.cmsProjects = scope;
    const request = new URLSearchParams(location.search).get('project');
    if (scope === 'projects' && request && request !== requestedProject) { requestedProject = request; openProject(request, false); }
    if (!request) requestedProject = null;
  }

  function closeProject() {
    const dialog = document.getElementById('cms-project-dialog');
    if (dialog?.open) dialog.close();
    const url = new URL(location.href);
    if (url.searchParams.has('project')) { url.searchParams.delete('project'); history.replaceState(history.state, '', url); }
    requestedProject = null;
  }

  function openProject(id, updateUrl = true) {
    const project = visibleProjects().find(item => item.id === id);
    if (!project) return;
    let dialog = document.getElementById('cms-project-dialog');
    if (!dialog) {
      dialog = document.createElement('dialog'); dialog.id = 'cms-project-dialog'; dialog.className = 'cms-project-dialog';
      dialog.addEventListener('cancel', event => { event.preventDefault(); closeProject(); });
      dialog.addEventListener('click', event => { if (event.target === dialog) closeProject(); });
      document.body.append(dialog);
    }
    const images = gallery(project);
    dialog.innerHTML = `<button type="button" class="cms-dialog-close" aria-label="Close project" data-cms-close-project>×</button><div class="cms-detail-image">${imageTag(images[0], project.title, 'data-cms-detail-image')}</div><div class="cms-detail-body"><span class="cms-detail-status">${status(project)}</span><h2 id="cms-project-title">${escape(project.title)}</h2><p class="cms-detail-location">${escape(project.category)} · ${escape(project.location)}</p><p>${escape(project.summary)}</p>${project.description ? `<p>${escape(project.description).replace(/\n/g, '<br>')}</p>` : ''}${images.length > 1 ? `<div class="cms-detail-thumbs">${images.map((src, i) => `<button type="button" aria-label="View gallery image ${i + 1}" data-cms-detail-src="${escape(safeImage(src))}">${imageTag(src, '')}</button>`).join('')}</div>` : ''}${project.features?.length ? `<h3>Project highlights</h3><ul class="cms-detail-features">${project.features.map(item => `<li>${escape(item)}</li>`).join('')}</ul>` : ''}<a class="cms-site-button" href="${escape(enquiry(project))}">Enquire about this project <span aria-hidden="true">↗</span></a></div>`;
    dialog.setAttribute('aria-labelledby', 'cms-project-title');
    if (!dialog.open) dialog.showModal();
    if (updateUrl && location.pathname.replace(/\/$/, '') === '/projects') {
      const url = new URL(location.href); url.searchParams.set('project', id); history.replaceState(history.state, '', url); requestedProject = id;
    }
    applyImages();
  }

  function apply() {
    queued = false;
    const preloader = document.querySelector('.pre');
    if (preloader && preloader.style.display !== 'none') {
      if (!hydrationTimer) hydrationTimer = setTimeout(() => { hydrationTimer = null; schedule(); }, 100);
      return;
    }
    if (lastPath !== location.pathname) { lastPath = location.pathname; load(); }
    if (content) { renderProjects(); applyImages(); }
  }
  function schedule() { if (!queued) { queued = true; requestAnimationFrame(apply); } }

  async function load() {
    if (loading) return;
    loading = true;
    try {
      const response = await fetch('/cms/api.php?action=' + (preview ? 'preview' : 'content'), {cache: 'no-store', credentials: 'same-origin'});
      if (!response.ok) throw new Error('Content request failed');
      const next = await response.json();
      if (!Array.isArray(next.projects) || !next.images) return;
      content = next; loadedAt = Date.now();
      if (!preview) { try { localStorage.setItem('malghe-public-content', JSON.stringify(next)); } catch {} }
      schedule();
    } catch { /* The original exported content remains available if the CMS is unavailable. */ }
    finally { loading = false; }
  }

  if (!preview) { try { content = JSON.parse(localStorage.getItem('malghe-public-content')); } catch {} }
  if (preview) {
    const banner = document.createElement('aside'); banner.className = 'cms-preview-banner';
    banner.innerHTML = 'Saved draft preview <a href="/">View published site ↗</a>'; document.body.append(banner);
  }
  new MutationObserver(schedule).observe(document.documentElement, {subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'srcset']});
  document.addEventListener('click', event => {
    const open = event.target.closest('[data-cms-open-project]'); if (open) openProject(open.dataset.cmsOpenProject);
    if (event.target.closest('[data-cms-close-project]')) closeProject();
    const detail = event.target.closest('[data-cms-detail-src]');
    if (detail) { const image = document.querySelector('[data-cms-detail-image]'); if (image) { originalImages.delete(image); image.src = detail.dataset.cmsDetailSrc; } }
    const thumb = event.target.closest('[data-cms-gallery]');
    if (thumb) {
      const project = visibleProjects().find(item => item.id === thumb.dataset.cmsGallery);
      const section = thumb.closest('[data-cms-owned]');
      if (project && section) {
        const image = section.querySelector('[data-cms-feature-image]'); originalImages.delete(image); image.src = safeImage(gallery(project)[Number(thumb.dataset.index)]);
        for (const button of section.querySelectorAll('[data-cms-gallery]')) button.classList.toggle('is-active', button === thumb);
      }
    }
  });
  addEventListener('popstate', () => { closeProject(); schedule(); });
  addEventListener('pageshow', load);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && Date.now() - loadedAt > 15000) load(); });
  schedule(); load();
})();
