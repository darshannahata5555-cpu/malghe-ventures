<?php
// Only a one-time setup hash is shipped. Owner credentials live outside public_html.
return ['setup_token_hash' => '6c02d1624294eb35eead09a756f83a8e6b6a3008087f1bb3330c507e50063cb4'];
