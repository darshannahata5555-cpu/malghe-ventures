<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
try {
    $file = $_GET['file'] ?? '';
    if (!is_string($file) || !preg_match('/^[a-f0-9]{32}\.(jpg|png|webp|avif)$/D', $file)) { http_response_code(404); exit; }
    $path = cms_storage() . '/media/' . $file;
    if (!is_file($path)) { http_response_code(404); exit; }
    $mime = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'avif' => 'image/avif'][pathinfo($file, PATHINFO_EXTENSION)];
    header('Content-Type: ' . $mime); header('X-Content-Type-Options: nosniff'); header('Cache-Control: public, max-age=31536000, immutable');
    $tag = '"' . $file . '"'; header('ETag: ' . $tag);
    if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $tag) { http_response_code(304); exit; }
    header('Content-Length: ' . filesize($path)); readfile($path);
} catch (Throwable $e) { http_response_code(500); }
